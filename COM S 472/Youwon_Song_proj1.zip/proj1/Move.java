package edu.iastate.cs472.proj1;

/**
 * 
 * Different moves on the board
 *
 */
public enum Move 
{
	LEFT, RIGHT, UP, DOWN,  DBL_LEFT, DBL_RIGHT, DBL_UP, DBL_DOWN
}
