package arithlang;
import static arithlang.AST.*;
import static arithlang.Value.*;

import java.util.List;

public class Evaluator implements Visitor<Value> {
    private NumVal record = new NumVal(" ");
    Printer.Formatter ts = new Printer.Formatter();
	
    Value valueOf(Program p) {
        // Value of a program in this language is the value of the expression
        return (Value) p.accept(this);
    }
	
    @Override
    public Value visit(AddExp e) {
        List<Exp> operands = e.all();

        String result = ""; String s1 = ""; String s2 = "";
        int i = 0;

        for(Exp exp: operands) {
            NumVal intermediate = (NumVal) exp.accept(this);

            switch (i){
                case 0:
                    s1 = intermediate.v();
                    break;
                case 1:
                    s2 = intermediate.v();
                    break;
            }
            i++;
        }

        if((s1.compareTo("e") == 0 && s2.compareTo("e") == 0) ||
                (s1.compareTo("o") == 0 && s2.compareTo("o") == 0)){

            result = "e";

        }else if((s1.compareTo("o") == 0 && s2.compareTo("e") == 0) ||
                (s1.compareTo("e") == 0 && s2.compareTo("o") == 0)){

            result = "o";

        }else if(s1.compareTo("u") == 0 || s2.compareTo("u") == 0){

            result = "u";

        }else{

            result = "Invalid error";
        }
        return new NumVal(result);
    }

    @Override
    public Value visit(NumExp e) {
        return new NumVal(e.v());
    }


    @Override
    public Value visit(MultExp e) {
        List<Exp> operands = e.all();

        String result = ""; String s1 = ""; String s2 = "";
        int i = 0;

        for(Exp exp: operands) {
            NumVal intermediate = (NumVal) exp.accept(this);

            switch (i){
                case 0:
                    s1 = intermediate.v();
                    break;
                case 1:
                    s2 = intermediate.v();
                    break;
            }
            i++;
        }

        if((s1.compareTo("e") == 0 && s2.compareTo("o") == 0) ||
                (s1.compareTo("e") == 0 && s2.compareTo("e") == 0) ||
                (s1.compareTo("o") == 0 && s2.compareTo("e") == 0)){

            result = "e";

        }else if((s1.compareTo("o") == 0 && s2.compareTo("o") == 0)){

            result = "o";

        }else if(s1.compareTo("u") == 0 || s2.compareTo("u") == 0){

            result = "u";

        }else{
            result = "Invalid error";
        }
        return new NumVal(result);
    }

    @Override
    public Value visit(Program p) {
        return (Value) p.e().accept(this);
    }

}
