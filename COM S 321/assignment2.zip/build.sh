gcc disassembly.c -o disassembly
