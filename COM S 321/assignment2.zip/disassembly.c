// Author : Youwon Song, uwon@iastate.edu
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <endian.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#define OPCODE11(i)  (((i) >> 21) & 0x7FF)   // 11-bit opcode
#define OPCODE10(i)  (((i) >> 22) & 0x3FF)   // 10-bit opcode
#define OPCODE8(i)   (((i) >> 24) & 0xFF)    // 8-bit opcode
#define OPCODE6(i)   (((i) >> 26) & 0x3F)    // 6-bit opcode

#define RD(i)        ((i) & 0x1F)
#define RN(i)        (((i) >> 5) & 0x1F)
#define RM(i)        (((i) >> 16) & 0x1F)
#define SHAMT(i)     (((i) >> 10) & 0x3F)

#define IMM12(i)     (((i) >> 10) & 0xFFF)
#define ADDR9(i)     (((i) >> 12) & 0x1FF)
#define RT(i)        ((i) & 0x1F)
#define IMM26(i)     ((i) & 0x03FFFFFF)
#define IMM19(i)     (((i) >> 5) & 0x7FFFF)

static inline int32_t sign_extend(int32_t value, int bits) {
    int32_t mask = 1 << (bits - 1);
    return (value ^ mask) - mask;
}

static const char *cond_names[16] = {
    "EQ","NE","HS","LO",
    "MI","PL","VS","VC",
    "HI","LS","GE","LT",
    "GT","LE",NULL,NULL
};

void print_reg(int r) {
    if (r == 31) printf("XZR");  
    else printf("X%d", r);
}

/* 1-pass: mark labels at branch target locations */
void decode_and_collect_labels(uint32_t inst, uint32_t pc, int *has_label, size_t n_insts) {
    uint32_t opc6 = OPCODE6(inst);
    uint32_t opc8 = OPCODE8(inst);

    /* B / BL : 26-bit offset */
    if (opc6 == 0b000101 || opc6 == 0b100101) {
        int32_t offset = sign_extend(IMM26(inst), 26) << 2;
        uint32_t target_pc = pc + offset;
        size_t idx = target_pc / 4;
        if (idx < n_insts) has_label[idx] = 1;
        return;
    }

    /* CBZ / CBNZ / B.cond (CB-format) : 19-bit offset */
    if (opc8 == 0b10110100 || opc8 == 0b10110101 ||  // CBZ / CBNZ
        opc8 == 0b01010100) {                        // B.cond
        int32_t offset = sign_extend(IMM19(inst), 19) << 2;
        uint32_t target_pc = pc + offset;
        size_t idx = target_pc / 4;
        if (idx < n_insts) has_label[idx] = 1;
        return;
    }
}

/* 2-pass: disassemble and print */
void decode_and_print(uint32_t inst, uint32_t pc) {
    uint32_t opc11 = OPCODE11(inst);
    uint32_t opc10 = OPCODE10(inst);
    uint32_t opc8  = OPCODE8(inst);
    uint32_t opc6  = OPCODE6(inst);

    /*  1) 11-bit opcode: R / D */
    switch (opc11) {
        case 0b10001011000:  // ADD (R)
            printf("    ADD ");
            print_reg(RD(inst)); printf(", ");
            print_reg(RN(inst)); printf(", ");
            print_reg(RM(inst)); printf("\n");
            return;

        case 0b11001011000:  // SUB (R)
            printf("    SUB ");
            print_reg(RD(inst)); printf(", ");
            print_reg(RN(inst)); printf(", ");
            print_reg(RM(inst)); printf("\n");
            return;

        case 0b11101011000:  // SUBS (R)  <-- double-check in opcodes.txt
            printf("    SUBS ");
            print_reg(RD(inst)); printf(", ");
            print_reg(RN(inst)); printf(", ");
            print_reg(RM(inst)); printf("\n");
            return;

        case 0b10001010000:  // AND (R)
            printf("    AND ");
            print_reg(RD(inst)); printf(", ");
            print_reg(RN(inst)); printf(", ");
            print_reg(RM(inst)); printf("\n");
            return;

        case 0b11001010000:  // EOR (R)
            printf("    EOR ");
            print_reg(RD(inst)); printf(", ");
            print_reg(RN(inst)); printf(", ");
            print_reg(RM(inst)); printf("\n");
            return;

        case 0b10101010000:  // ORR (R)
            printf("    ORR ");
            print_reg(RD(inst)); printf(", ");
            print_reg(RN(inst)); printf(", ");
            print_reg(RM(inst)); printf("\n");
            return;

        case 0b10011011000:  // MUL (R)
            printf("    MUL ");
            print_reg(RD(inst)); printf(", ");
            print_reg(RN(inst)); printf(", ");
            print_reg(RM(inst)); printf("\n");
            return;

        case 0b11111000010: { // LDUR (D)
            int32_t offset = sign_extend(ADDR9(inst), 9);
            printf("    LDUR ");
            print_reg(RT(inst)); printf(", [");
            print_reg(RN(inst)); printf(", #%d]\n", offset);
            return;
        }

        case 0b11111000000: { // STUR (D)
            int32_t offset = sign_extend(ADDR9(inst), 9);
            printf("    STUR ");
            print_reg(RT(inst)); printf(", [");
            print_reg(RN(inst)); printf(", #%d]\n", offset);
            return;
        }

        case 0b11010011011: { // LSL (R-shift)
            int sh = SHAMT(inst);
            printf("    LSL ");
            print_reg(RD(inst)); printf(", ");
            print_reg(RN(inst)); printf(", #%d\n", sh);
            return;
        }

        case 0b11010011010: { // LSR (R-shift)
            int sh = SHAMT(inst);
            printf("    LSR ");
            print_reg(RD(inst)); printf(", ");
            print_reg(RN(inst)); printf(", #%d\n", sh);
            return;
        }

        case 0b11010110000: { // BR Rn
            printf("    BR ");
            print_reg(RN(inst));  // branch target register is in Rn field
            printf("\n");
            return;
        }

        case 0b11111111101:  // PRNT
            printf("    PRNT ");
            print_reg(RD(inst)); printf("\n");
            return;

        case 0b11111111100:  // PRNL
            printf("    PRNL\n");
            return;

        case 0b11111111110:  // DUMP
            printf("    DUMP\n");
            return;

        case 0b11111111111:  // HALT
            printf("    HALT\n");
            return;
    }

    /*  2) 10-bit opcode: I-format */
    switch (opc10) {
        case 0b1001000100: { // ADDI
            int32_t imm = sign_extend(IMM12(inst), 12);
            printf("    ADDI ");
            print_reg(RD(inst)); printf(", ");
            print_reg(RN(inst)); printf(", #%d\n", imm);
            return;
        }

        case 0b1101000100: { // SUBI
            int32_t imm = sign_extend(IMM12(inst), 12);
            printf("    SUBI ");
            print_reg(RD(inst)); printf(", ");
            print_reg(RN(inst)); printf(", #%d\n", imm);
            return;
        }

        case 0b1111000100: { // SUBIS  <-- check in opcodes.txt
            int32_t imm = sign_extend(IMM12(inst), 12);
            printf("    SUBIS ");
            print_reg(RD(inst)); printf(", ");
            print_reg(RN(inst)); printf(", #%d\n", imm);
            return;
        }

        case 0b1001001000: { // ANDI
            int32_t imm = sign_extend(IMM12(inst), 12);
            printf("    ANDI ");
            print_reg(RD(inst)); printf(", ");
            print_reg(RN(inst)); printf(", #%d\n", imm);
            return;
        }

        case 0b1011001000: { // ORRI
            int32_t imm = sign_extend(IMM12(inst), 12);
            printf("    ORRI ");
            print_reg(RD(inst)); printf(", ");
            print_reg(RN(inst)); printf(", #%d\n", imm);
            return;
        }

        case 0b1101001000: { // EORI
            int32_t imm = sign_extend(IMM12(inst), 12);
            printf("    EORI ");
            print_reg(RD(inst)); printf(", ");
            print_reg(RN(inst)); printf(", #%d\n", imm);
            return;
        }

    }

    /* 3) 6-bit opcode: B / BL */
    if (opc6 == 0b000101) {  // B
        int32_t offset = sign_extend(IMM26(inst), 26) << 2;
        uint32_t target_pc = pc + (uint32_t)offset;
        size_t target_idx = target_pc / 4;
        printf("    B label_%zu\n", target_idx);
        return;
    } else if (opc6 == 0b100101) { // BL
        int32_t offset = sign_extend(IMM26(inst), 26) << 2;
        uint32_t target_pc = pc + (uint32_t)offset;
        size_t target_idx = target_pc / 4;
        printf("    BL label_%zu\n", target_idx);
        return;
    }

    /* 4) 8-bit opcode: CBZ / CBNZ / B.cond */
    if (opc8 == 0b10110100) {  // CBZ
        int32_t offset = sign_extend(IMM19(inst), 19) << 2;
        uint32_t target_pc = pc + (uint32_t)offset;
        size_t target_idx = target_pc / 4;
        printf("    CBZ ");
        print_reg(RT(inst)); printf(", label_%zu\n", target_idx);
        return;
    } else if (opc8 == 0b10110101) {  // CBNZ
        int32_t offset = sign_extend(IMM19(inst), 19) << 2;
        uint32_t target_pc = pc + (uint32_t)offset;
        size_t target_idx = target_pc / 4;
        printf("    CBNZ ");
        print_reg(RT(inst)); printf(", label_%zu\n", target_idx);
        return;
    } else if (opc8 == 0b01010100) {  // B.cond
        int32_t offset = sign_extend(IMM19(inst), 19) << 2;
        uint32_t target_pc = pc + (uint32_t)offset;
        size_t target_idx = target_pc / 4;
        int cond = RT(inst);   
        const char *cname = (cond >= 0 && cond < 16) ? cond_names[cond] : NULL;
        if (!cname) cname = "??";
        printf("    B.%s label_%zu\n", cname, target_idx);
        return;
    }

    /*  output as .word */
    printf("    .word 0x%08X\n", inst);
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "usage: %s <binary file>\n", argv[0]);
        return 1;
    }

    int fd = open(argv[1], O_RDONLY);
    if (fd < 0) {
        perror("open");
        return 1;
    }

    struct stat buf;
    if (fstat(fd, &buf) < 0) {
        perror("fstat");
        close(fd);
        return 1;
    }

    if (buf.st_size % 4 != 0) {
        fprintf(stderr, "file size is not multiple of 4 bytes\n");
        close(fd);
        return 1;
    }

    uint32_t *program = mmap(NULL, buf.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
    if (program == MAP_FAILED) {
        perror("mmap");
        close(fd);
        return 1;
    }

    size_t n_insts = buf.st_size / 4;

    uint32_t *insts = calloc(n_insts, sizeof(uint32_t));
    if (!insts) {
        perror("calloc");
        munmap(program, buf.st_size);
        close(fd);
        return 1;
    }

    /* big-endian → host-endian */
    for (size_t i = 0; i < n_insts; i++) {
        insts[i] = be32toh(program[i]);
    }

    munmap(program, buf.st_size);
    close(fd);

    int *has_label = calloc(n_insts, sizeof(int));
    if (!has_label) {
        perror("calloc");
        free(insts);
        return 1;
    }

    /* 1-pass: collect label position  */
    for (size_t i = 0; i < n_insts; i++) {
        uint32_t pc = (uint32_t)(i * 4);
        decode_and_collect_labels(insts[i], pc, has_label, n_insts);
    }

    /* 2-pass: print label + disassembly */
    for (size_t i = 0; i < n_insts; i++) {
        if (has_label[i]) {
            printf("label_%zu:\n", i);
        }
        uint32_t pc = (uint32_t)(i * 4);
        decode_and_print(insts[i], pc);
    }

    free(has_label);
    free(insts);
    return 0;
}
