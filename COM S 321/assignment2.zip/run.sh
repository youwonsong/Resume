./disassembly "$1"
