function validate(){

    var status = true;

    //fisrt name 

    if((document.getElementById('fname').value).match(/^[A-Za-z0-9]+$/)){

        document.getElementById('fnameResult').src = 'correct.png'

    }else{

        document.getElementById('fnameResult').src = 'wrong.png'
		alert('Must contain onlyalphabetic or numeric characters.')

        status = false;

    }

    //last name 

    if((document.getElementById('lname').value).match(/^[A-Za-z0-9]+$/)){

        document.getElementById('lnameResult').src = 'correct.png'

    }else{

        document.getElementById('lnameResult').src = 'wrong.png'
		alert('Must contain onlyalphabetic or numeric characters.')

        status = false;

    }

    //gender

    if((document.getElementById('gender').value) != "select" ){

        document.getElementById('genderResult').src = 'correct.png'

    }else{

        document.getElementById('genderResult').src = 'wrong.png'

        status = false;

    }

    //state 

    if((document.getElementById('state').value) != "select" ){

        document.getElementById('stateResult').src = 'correct.png'

    }else{

        document.getElementById('stateResult').src = 'wrong.png'
		alert('Select from given list.')

        status = false;

    }

    //success

    if(status){


        alert('Success.');

        document.getElementById("myForm").submit();
		documnet.location.href=validation2.html
    }

}