function valid()
{
   //access all values in the input field
        var email=document.getElementById("email").value;
        //alert(email);
        var phone=document.getElementById("phone").value;
        var address=document.getElementById("address").value;
        //alert(address);
        //regular expression for email
       if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email))
       {
             document.getElementById("imgage").innerHTML = "<img src=\"correct.png\" height=\"50\" width=\"50\"/>"
       }
       else
       {
             document.getElementById("imgage").innerHTML = "<img src=\"wrong.png\" height=\"50\" width=\"50\"/>"
             alert('Must be in the formxxx@xxx.xxxx should be alphanumeric (e.g. nospecial symbols).');
       }

//regular expression for phone number
      var phoneno =/^\(?([0-9]{3})\)?[- ]?([0-9]{3})[- ]?([0-9]{4})$/;  
      if(phone.match(phoneno))
      {
             document.getElementById("imgage2").innerHTML = "<img src=\"correct.png\" height=\"50\" width=\"50\"/>"
      }
      else
      {
                document.getElementById("imgage2").innerHTML = "<img src=\"wrong.png\" height=\"50\" width=\"50\"/>"
                alert('Must be in the formxxx-xxx-xxxx orxxxxxxxxxx.x should be numeric');
       }
//regx for address
      if(/^\w+(,\w+)*$/.test(address))
      {
         document.getElementById("imgage3").innerHTML ="<img src=\"correct.png\" height=\"50\" width=\"50\"/>"
       }
       else
        {
                document.getElementById("imgage3").innerHTML = "<img src=\"wrong.png\" height=\"50\" width=\"50\"/>"
                alert('Must be in the form ofcity & state.example:Ames,IA');
        }
        
}