function left() {

	console.log('left')

	if (speedX != 0) {

		if (speedX < 0) {

			// moving left direction

			// then move down

			speedX = 0

			speedY = 1

		}



		if (speedX > 0) {

			// if moving right direction

			// then move up

			speedX = 0

			speedY = -1

		}

	}

	else if (speedY != 0) {

		if (speedY < 0) {

			// moving up direction

			// then move left

			speedX = -1

			speedY = 0

		}



		if (speedY > 0) {

			// if moving down direction

			// then move right

			speedX = 1

			speedY = 0

		}

	}

}

function right() {

	console.log('right')

	if (speedX != 0) {

		if (speedX < 0) {

			// moving left direction

			// then move up

			speedX = 0

			speedY = -1

		}



		if (speedX > 0) {

			// if moving right direction

			// then move down

			speedX = 0

			speedY = 1

		}

	}

	else if (speedY != 0) {

		if (speedY < 0) {

			// moving up direction

			// then move right

			speedX = 1

			speedY = 0

		}



		if (speedY > 0) {

			// if moving down direction

			// then move left

			speedX = -1

			speedY = 0

		}

	}

}

function stop() {

	var elem = document.getElementById("stopbtn");



	if (elem.value == "stop") {

		//change btn text

		elem.value = 'start'

		saveX = speedX; saveY = speedY; // save the motion direction, so we can restore it when start button clicked

		speedX = 0;

		speedY = 0

	}

	else {

		//change btn text

		elem.value = 'stop'

		speedX = saveX; speedY = saveY // restore speed direction

	}

	// set speed as 0

}