
var readlineSync = require('readline-sync');

var n1 = parseInt(readlineSync.question('1 Number : '));

var n2 = parseInt(readlineSync.question('2 Number : '));

var n3 = parseInt(readlineSync.question('3 Number : '));

var n4 = parseInt(readlineSync.question('4 Number : '));

var pro = 1;

for (let i = 1; i <= n1; i++) {

pro *= i;

}

console.log("Factorial of the 1st number is = ", pro);

var sum = 0;

while (n2) {

sum = sum + n2 % 10;

n2 = Math.floor(n2 / 10);

}

console.log("The sum of all the digits of the 2nd number is = ", sum);

console.log("The Reverse of the 3rd number is = ", num3.toString().split("").reverse().join(""));

var result = (n4.toString().split("").reverse().join("") == n4.toString()) ? "true" : "false";

console.log("Is the 4th Number a Palindrome(True/False)? ", result);